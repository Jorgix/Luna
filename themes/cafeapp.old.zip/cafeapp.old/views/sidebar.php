<div class="app_sidebar_nav">
    <a class="icon-home radius transition" title="Dashboard" href="<?= url("/app"); ?>">Controle</a>
    <a class="icon-calendar-check-o radius transition" title="Receber" href="<?= url("/app/receber"); ?>">Receber</a>
    <a class="icon-calendar-minus-o radius transition " title="Pagar" href="<?= url("/app/pagar"); ?>">Pagar</a>
    <a class="icon-exchange radius transition " title="Fixas" href="<?= url("/app/fixas"); ?>">Fixas</a>
    <a class="icon-user radius transition" title="Meu Perfil" href="<?= url("/app/perfil"); ?>">Meu Perfil</a>
    <a class="icon-sign-out radius transition" title="Sair" href="<?= url("/app/sair"); ?>">Sair</a>
</div>